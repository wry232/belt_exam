from django.conf.urls import url
# from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^register$', views.register),
    url(r'^login$', views.login),
    # url(r'^travel_info/(?P<user>\w+)$', views.travel_info),
     url(r'^travel_info$', views.travel_info),
     url(r'^/destination/(?P<id>\d+)$', views.destination),
     url(r'^addTrip$', views.addTrip),
]

