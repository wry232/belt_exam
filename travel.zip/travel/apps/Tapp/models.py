from __future__ import unicode_literals

from django.db import models
# import bcrypt
import re
# EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
# Create your models here.
class UserManager(models.Manager):
    def isValid(self, email, email_REGEX):
        if not email_REGEX. match (email):
           return False
        else:
           return True
    # def login (self, **kwargs):
    #   myUser = self.raw ('select * from mh_user_user where email = %s', [kwargs['email'][0]])
    #   try:
    #     myUser[0]
    #     print myUser[0]
    #     password = bcrypt.hashpw(kwargs['password'][0].encode('utf-8'), bcrypt.gensalt())
    #     if
    #     bcrypt.hashpw(kwargs['password'][0].encode('utf-8'), myUser[0].password.encode('utf-8') ==myUser[0].password:
    #       return (True, myUser)
    #   except IndexError:
    #       pass
    #   return (False, {'login': 'Login did no succeed'})
# Create your models here.
class User(models.Model):
      user = models.CharField(max_length=45)
      username = models.CharField(max_length=45)

      # email = models.CharField(max_length=100)
      password = models.CharField(max_length=100)
      confirm_password = models.CharField(max_length=100)
      created_at = models.DateTimeField(auto_now_add = True)
      updated_at = models.DateTimeField(auto_now = True)
      objects = UserManager()

class Travel(models.Model):
      user= models.ForeignKey(User)
      # name = models.CharField(max_length=45)
    #   title = models.CharField(max_length = 100)
      destination = models.TextField(max_length = 1000)

    #   first_name = models.CharField(max_length=45)
    #   last_name = models.CharField(max_length=45)
    #   password = models.CharField(max_length=100)
      start_at = models.DateTimeField(auto_now_add = True)
      end_at = models.DateTimeField(auto_now_add = True)
      plan = models.TextField(max_length = 1000)
      created_at = models.DateTimeField(auto_now_add = True)
      updated_at = models.DateTimeField(auto_now = True)

