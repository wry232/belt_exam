from django.shortcuts import render, redirect, HttpResponse
from .models import User,Travel
import re
from django.contrib import messages
# import bcrypt
import bcrypt
import datetime

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
NAME_REGEX = re.compile (r'^(.*?[a-zA-Z]){2,}.*$')
PASSWORD_REGEX = re.compile(r'[A-Za-z0-9@#$%^&+=]{8,}')
# Create your views here.
def index(request):
     context = {
        'users': User.objects.all()
     }
     return render (request, 'Tapp/index.html', context)
def register(request):
    name = request.POST['name']
    username = request.POST['user_name']
    # email = request.POST['email']
    password  = request.POST['password']
    confirm_password  = request.POST['confirm_password']
    if (User.objects.isValid (name, NAME_REGEX) == False):
        messages.error(request, 'name is not valid. ')
        return redirect('/')
    elif (len(username)<2):
        messages.error(request, 'User name is not valid. ')
        return redirect('/')
    # elif (User.objects.isValid (email, EMAIL_REGEX) == False):
    #     messages.error(request, 'Email is not valid. ')
    #     return redirect('/')
    elif (User.objects.isValid (password, PASSWORD_REGEX) == False):
        messages.error(request, 'Password is not valid. ')
        return redirect('/')
    elif (confirm_password != password):
        messages.error(request, 'Password is not consistant. ')
        return redirect('/')
    else:
        password = password.encode()
        hashed = bcrypt.hashpw(password, bcrypt.gensalt())
        User.objects.create (user = name, username = username,  password = hashed, confirm_password =hashed)
        context = {
        'username': username,
        'users':User.objects.all(),
        'user':name

        }
        # request.session['object'] = User.objects.filter (email = email)
        print "!!!!!!!!!"
        return render (request, 'Tapp/success.html', context)
def login(request):
    username = request.POST['user_name']
    password  = request.POST['password']
    password = password.encode()

    obj = User.objects.get (username = username)
    context = {
        'username' : obj. username
        }
    # ps_hashed = bcrypt.hashpw(password, bcrypt.gensalt())
    ps_hashed = obj.password
    ps_hashed = ps_hashed.encode()
    if bcrypt.hashpw(password, ps_hashed):
        return render (request, 'Tapp/success.html', context)
    else:
        messages.error(request, 'email or password wrong, check and enter again. ')
        return redirect('/')
def travel_info(request):


    user = User.objects.create(username = request.POST['user'])
    username = user.username
    destination = request.POST['destination']
    plan  = request.POST['plan']
    print "!!!!!!!!!222222"
    # Travel.objects.create (user = user, destination = destination,  start_date = start_date, end_date =end_date, plan = plan)
    Travel.objects.create (user = user, destination = destination,  plan = plan)

    context = {
        'user':user,
        'travels': Travel.objects.all(),
        'username':username,
        'destination':destination,
        'start_date': datetime.datetime.now(),
        'end_date':datetime.datetime.now(),
        'plan':plan
     }
    return render (request, 'Tapp/travels.html', context)
def destination(request,id):
    place= Travel.objects.get (id = id)
    context = {
        "travel": place
    }
    return render (request, 'Tapp/destination.html', context)

def addTrip(request):
    return render (request, 'Tapp/success.html')
